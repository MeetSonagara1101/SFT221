#pragma once
#pragma once
#ifndef MATHFUNCS_H
#define MATHFUNCS_H

double square(double n);
double cube(double n);

#endif